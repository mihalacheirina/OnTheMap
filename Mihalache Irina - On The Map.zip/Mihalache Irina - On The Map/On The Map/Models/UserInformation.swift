//
//  UserInformation.swift
//  On The Map
//
//  Created by Irina on 10/12/2019.
//  Copyright © 2019 Irina. All rights reserved.
//

import Foundation

struct UserInformation {
    static var firstName = ""
    static var lastName = ""
    static var uniqueKey = ""
}

