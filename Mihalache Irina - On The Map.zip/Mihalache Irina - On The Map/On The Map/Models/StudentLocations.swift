//
//  StudentLocations.swift
//  On The Map
//
//  Created by Irina on 10/12/2019.
//  Copyright © 2019 Irina. All rights reserved.
//

import Foundation

class StudentsLocations {
    static var sharedObject = StudentsLocations()
    var studentsLocations: [StudentLocation]?
}
