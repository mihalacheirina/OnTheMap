//
//  StudentsTableViewCell.swift
//  On The Map
//
//  Created by Irina on 02/12/2019.
//  Copyright © 2019 Irina. All rights reserved.
//

import UIKit

class StudentsTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var pinImage: UIImageView!
    @IBOutlet weak var studentName: UILabel!
    @IBOutlet weak var mediaURL: UILabel!
    
   func cellConfig(studentInformation: StudentLocation) {
        pinImage.image = UIImage(named:"icon_pin")//placeholder
        studentName.text =  (studentInformation.firstName ?? "No") + " " + (studentInformation.lastName ?? "Name")
        mediaURL.text = studentInformation.mediaURL
    }
    
}

