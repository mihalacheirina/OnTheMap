//
//  AddLocationViewController.swift
//  On The Map
//
//  Created by Irina on 02/12/2019.
//  Copyright © 2019 Irina. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Foundation

class AddLocationViewController: UIViewController, UITextFieldDelegate {
    
    var locations: [StudentLocation]! {
        return StudentsLocations.sharedObject.studentsLocations
    }
    
    @IBOutlet weak var locationName: UITextField!
    @IBOutlet weak var mediaURL: UITextField!
    @IBOutlet weak var findLocation: UIButton!
    
    var locationCoordinates: CLLocationCoordinate2D!
    var locationTitle: String!
    var url: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           self.subscribeToKeyboardNotifications()
       }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.unsubscribeFromKeyboardNotifications()
    }
    
    @IBAction func findLocationButton(_ sender: Any) {
         guard let url = mediaURL.text, let locationName = locationName.text, mediaURL.text!.lowercased().hasPrefix("https://") || mediaURL.text!.lowercased().hasPrefix("http://")  else {
                   print("Warning: Missing or Invalid Information. You must enter the location name and a valid link that includes http(s)://")
                   return
               }
               setLocationCoordinates(location: locationName) { (locationCoordinates, error) in
                   if error != nil {
                       print("Try Another Place.")
                       return
                   }
                   self.locationCoordinates = locationCoordinates
                   self.locationTitle = locationName
                   self.url = url
                   self.performSegue(withIdentifier: "showLocation", sender: self)
               }
           }
           
           //MARK: - Navigation
           override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
               if segue.identifier == "showLocation" {
                   let viewController = segue.destination as! StudentLocationViewController
                viewController.locationTitle = self.locationTitle
                viewController.selectedLocation = self.locationCoordinates
                   print(locationCoordinates!)
                   viewController.mediaURL = self.url
               }
           }
    
    func setLocationCoordinates(location: String, completion: @escaping (_ locationCoordicates: CLLocationCoordinate2D?, _ error: Error?) -> ()) {
        //to get the location coordinates
        CLGeocoder().geocodeAddressString(location) { placemarks, error in completion(placemarks?.first?.location?.coordinate, error)
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}

