//
//  StudentLocationViewController.swift
//  On The Map
//
//  Created by Irina on 02/12/2019.
//  Copyright © 2019 Irina. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class StudentLocationViewController: UIViewController, MKMapViewDelegate {
    
    var locations: [StudentLocation]! {
        return StudentsLocations.sharedObject.studentsLocations
    }
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var finishButton: UIButton!
    
    var selectedLocation: CLLocationCoordinate2D!
    var locationTitle:String!
    var mediaURL:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        createAnnotation()
    }
    
    @IBAction func finishTapped(_ sender: Any) {
       
        ParseAPI.postStudentLocation(mapString: locationTitle, mediaURL: mediaURL, locationCoordinates: selectedLocation, completion: { error in
            if error != nil {
                        self.alert(title: "Error", message: "Somthing Went Wrong. Try Again Later.")
                        return
                    }
                    UserDefaults.standard.set(self.locationTitle, forKey: "studentLocation")
                    DispatchQueue.main.async {
                        self.dismiss(animated: true, completion: nil)
                    }
                })
                
            }
    
    func createAnnotation(){
        let annotation = MKPointAnnotation()
        annotation.coordinate = selectedLocation!
        annotation.title = UserInformation.firstName + " " + UserInformation.lastName
        annotation.subtitle = mediaURL
        mapView.addAnnotation(annotation)
        // Setting current mapView's region to be centered at the pin's coordinate
        let region = MKCoordinateRegion(center: selectedLocation!, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        mapView.setRegion(region, animated: false)
    }
    
    func updateAnnotations(){
        
        var annotations = [MKPointAnnotation]()
        for studentLocation in locations {
            let lat = CLLocationDegrees(studentLocation.latitude!)
            let long = CLLocationDegrees(studentLocation.longitude!)
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
            
            let first = studentLocation.firstName!
            let last = studentLocation.lastName!
            let mediaURL = studentLocation.mediaURL!
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "\(String(describing: first)) \(String(describing: last))"
            annotation.subtitle = mediaURL
            annotations.append(annotation)
            if !mapView.annotations.contains(where: {$0.title == annotation.title}){
                annotations.append(annotation)
            }
        }
        print("New point annotation: ", annotations.count-100)//debug
        mapView.addAnnotations(annotations)
        
    }
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle!,
                let url = URL(string: toOpen), app.canOpenURL(url) {
                app.open(url, options: [:], completionHandler: nil)
            }
        }
    }
    
    @IBAction func refreshButton(_ sender: Any) {
          
           ParseAPI.getStudentsLocations { (_, error) in
           if error != nil {
               let alert = UIAlertController(title: "Error", message: "Somthing Went Wrong. Try Again Later.", preferredStyle: .alert)
               return
           }
           DispatchQueue.main.async {
               self.updateAnnotations()
           }
        }
    }
}

