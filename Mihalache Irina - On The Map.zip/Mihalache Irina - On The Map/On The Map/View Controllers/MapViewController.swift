//
//  MapViewController.swift
//  On The Map
//
//  Created by Irina on 02/12/2019.
//  Copyright © 2019 Irina. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {
    
    var locations: [StudentLocation]! {
        return StudentsLocations.sharedObject.studentsLocations
    }
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if (locations == nil){
            refreshStudentsLocations(self)
        } else {
            DispatchQueue.main.async {
                self.updateAnnotations()
            }
        }
    }
    
    @IBAction func refreshStudentsLocations(_ sender: Any) {
        
        ParseAPI.getStudentsLocations { (_, error) in
            if error != nil {
                self.alert(title: "Error", message: "Somthing went wrong!")
                return
            }
            DispatchQueue.main.async {
                self.updateAnnotations()
            }
            }
        }
    
    @IBAction func addNewLocation(_ sender: Any){
    
    if UserDefaults.standard.value(forKey: "studentLocation") != nil {
        }
        else {
            self.performSegue(withIdentifier: "addNewPin", sender: self)
        }
    }
    
     @IBAction func LogOutTapped(_ sender: Any) {
        ParseAPI.logout { (error) in
                if error != nil {
                    self.alert(title: "ERROR", message: error!.localizedDescription)
                    return
                }
                DispatchQueue.main.async {
                    self.updateAnnotations()
                }
            }
            self.dismiss(animated: true, completion: nil)
        }
        
    
    func updateAnnotations(){
        
        var annotations = [MKPointAnnotation]()
        for studentLocation in locations {
            let lat = CLLocationDegrees(studentLocation.latitude!)
            let long = CLLocationDegrees(studentLocation.longitude!)
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
            
            let first = studentLocation.firstName!
            let last = studentLocation.lastName!
            let mediaURL = studentLocation.mediaURL!
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "\(String(describing: first)) \(String(describing: last))"
            annotation.subtitle = mediaURL
            annotations.append(annotation)
            if !mapView.annotations.contains(where: {$0.title == annotation.title}){
                annotations.append(annotation)
            }
        }
        print("New point annotation: ", annotations.count-100)//debug
        mapView.addAnnotations(annotations)
        
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseid = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseid) as? MKPinAnnotationView
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseid)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        } else {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
    if control == view.rightCalloutAccessoryView {
        let app = UIApplication.shared
        if let toOpen = view.annotation?.subtitle!,
            let url = URL(string: toOpen), app.canOpenURL(url) {
            app.open(url, options: [:], completionHandler: nil)
            }
        }
    }
}
